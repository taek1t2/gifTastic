//generating new variables
var funnyAnimals

//Create an event listener on the ID of funny button.
$("button").on("click", function() {
    //creating a variable and storing our api link or endpoint url.
    var APIkey = "dPEAYWRtQ0hLXqQQWwjObzDQFraBMy93";
    var queryURL = "https://api.giphy.com/v1/gifs/random?api_key=dPEAYWRtQ0hLXqQQWwjObzDQFraBMy93&tag=&rating=G";

    // "https://api.giphy.com/v1/gifs/search?q=" + funnyAnimals + "&api_key=dPEAYWRtQ0hLXqQQWwjObzDQFraBMy93"

    // using ajax (part of jQuery) to make API call.
    $.ajax({
        url: queryURL,
        method: "GET"
    })
    // then passing the data from AJX to a function as a param called response
        .then(function(response) {
            //Storing the gif image from the returned object in a var.
            var imageUrl = response.data.images.original.url;
            console.log(queryURL);

            console.log(response);
            //create a new image tag '<>' and store it in a var
            var results = response.data;
            

            //Create a for loop for new results each time.
            for (var i = 0; i < results.length; i++) {
                //creating a new div and storing with the variable
                var funnyAnimals = $("<div>");

                //Creating a new p tag with the result item's rating on each images
                var p = $("<p>").text ("Rating: " + results[i].rating);
                //Storing the image in a new variable
                var funnyImage = $("<img>");
                // setting the src attribute of the image to a property pulled off the result item
                funnyAnimals.attr("src", results[i].images.fixed_height.url);
                funnyAnimals.attr("alt", "funny image");

                //then appending the paragraph and image tag to funnyAnimals
                funnyAnimals.append(p);
                funnyAnimals.append(funnyImage);

                //then prepending the funnyAnimal to the HTML page in the "#gifs-appear-here" div
                $("#gifs-appeaer-here").prepend(funnyAnimals);
                
            }
                
            
            // The attr jQuery method allows us to get or set the value of any attribute on our HTML element
            
            // If the clicked image's state is still, update its src attribute to what its data-animate value is.

            // Then, set the image's data-state to animate
            
            // Else set src to the data-still value

        })
})
    

